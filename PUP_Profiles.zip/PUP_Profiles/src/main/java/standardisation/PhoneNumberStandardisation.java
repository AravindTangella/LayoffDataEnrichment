package standardisation;

import com.google.i18n.phonenumbers.PhoneNumberUtil;
import com.google.i18n.phonenumbers.Phonenumber;
import common.Utility;

import java.util.logging.Logger;

import static common.Constants.EMPTY;
import static common.Constants.PLUS;

public class PhoneNumberStandardisation {
    private static final PhoneNumberUtil phoneNumberUtil = PhoneNumberUtil.getInstance();
    private static final Logger logger = Logger.getLogger(PhoneNumberStandardisation.class.getName());

    public static String getCountryCode(String phoneNumber) {

        // phoneNumber is null or no '+' sign in phone number return ""
        if (Utility.isValid(phoneNumber) || phoneNumber.indexOf(PLUS) < 0) {
            return EMPTY;
        }
        com.google.i18n.phonenumbers.Phonenumber.PhoneNumber phNumber =
                parsePhoneNumber(phoneNumber, "");

        return PLUS + phNumber.getCountryCode();
    }

    public static String standardise(String phoneNumber, String countryCode){
        String result = null;
        try {
            Phonenumber.PhoneNumber number = phoneNumberUtil.parse(phoneNumber, countryCode);
            if(phoneNumberUtil.isValidNumber(number)) result = phoneNumberUtil.format(number, PhoneNumberUtil.PhoneNumberFormat.E164);
        }catch (Exception e){
            return null;
        }
        return result;
    }

    public static Phonenumber.PhoneNumber parsePhoneNumber(String phoneNumber, String countryCode) {
        Phonenumber.PhoneNumber number = null;
        try {
            number = phoneNumberUtil.parse(phoneNumber, countryCode);
        } catch (Exception e) {
            return null;
        }
        return number;
    }
}
