package org.example;

import common.Utility;
import org.apache.http.HttpResponse;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.entity.StringEntity;
import org.apache.http.impl.client.CloseableHttpClient;
import org.apache.http.impl.client.HttpClientBuilder;
import org.apache.http.util.EntityUtils;
import org.apache.log4j.Logger;
import org.bson.Document;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import static common.Constants.*;
import static org.apache.log4j.LogManager.getLogger;


public class ProfileToES {
    static Logger log = getLogger(ProfileToES.class.getName());

    public static void update(Document profileDoc) {
        String socialProfile = profileDoc.get("socialProfile").toString();
        if(!Utility.isValid(socialProfile))
            return;
        List<String> socialProfiles= getSocialProfiles(socialProfile);
        Document requestDoc = new Document();
        requestDoc.put(SOCIAL_PROFILES, socialProfiles);

        Document ProfileMatchingResponse = API(GET_URL, GET_API_KEY,requestDoc);
        updateInES(ProfileMatchingResponse, profileDoc);
    }
    public static void updateInES(Document responseDoc, Document profileDoc) {
        if(responseDoc.get("status").equals(404))
            return;
        Document profileData = (Document) responseDoc.get("data");

        Document newProfileData = new Document();
        newProfileData.put("pupId", profileData.get("pupId"));
        newProfileData.put("emailList", getEmail(profileDoc));

        Document updatedResponse = API(UPDATE_URL, UPDATE_API_KEY,newProfileData);
        log.info(updatedResponse.toJson());
    }
    public static List<String> getSocialProfiles(String socialProfiles) {
        List<String> urls = new ArrayList<>();
        urls.add(socialProfiles);
        return urls;
    }

    public static Document API(String URL, String apiKey, Document requestDoc) {
        try(CloseableHttpClient client = HttpClientBuilder.create().build()) {
            String reqBody = requestDoc.toJson();
            HttpPost httpPost = new HttpPost(URL);
            httpPost.setHeader("content-type","application/json");
            httpPost.setHeader("Accept-Encoding", "UTF-8");
            httpPost.setHeader("api-key", apiKey);
            httpPost.setEntity(new StringEntity(reqBody,"UTF-8"));

            HttpResponse httpResponse = client.execute(httpPost);
            String responseInString = EntityUtils.toString(httpResponse.getEntity());
            Document responseDoc = Document.parse(responseInString);
            return responseDoc;
        } catch (IOException e) {
            throw new RuntimeException(e);
        }
    }

    public static List<Document> getEmail(Document profileDoc) {
        List<Document> newEmailList = new ArrayList<>();
        if(!Utility.isValid(profileDoc.get("email")))
            return newEmailList;

        String email = profileDoc.getString("email");
        Document newEmail = new Document();

        List<Document> validatedSourceList = new ArrayList<>();
        Document validatedSourceDoc = new Document();
        validatedSourceDoc.put("source", "");
        validatedSourceDoc.put("createdDate", "");
        validatedSourceDoc.put("updatedDate", System.currentTimeMillis());
        validatedSourceList.add(validatedSourceDoc);

        newEmail.put("email", email);
        newEmail.put("is_valid", true);
        newEmail.put("validated_source", validatedSourceList);
        newEmailList.add(newEmail);
        return newEmailList;
    }
    public static List<Document> getContacts(Document profileDoc) {
        List<Document> contactsList = new ArrayList<>();
        List<String> newContacts = (List<String>) profileDoc.get("contacts");
        if(newContacts == null || newContacts.isEmpty())
            return contactsList;
        for(String contact : newContacts) {
            Document newContact = new Document();
            newContact.put("phoneNumber", contact);
            newContact.put("is_valid", true);

            List<Document> validatedSource = new ArrayList<>();
            Document validSource = new Document();
            validSource.put("updatedDate", System.currentTimeMillis());
            validatedSource.add(validSource);

            newContact.put("validated_source", validatedSource);
            contactsList.add(newContact);
        }
        return contactsList;
    }
}
