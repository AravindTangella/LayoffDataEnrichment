package org.example;

import common.Utility;
import org.apache.http.HttpResponse;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.entity.StringEntity;
import org.apache.http.impl.client.CloseableHttpClient;
import org.apache.http.impl.client.HttpClientBuilder;
import org.apache.http.util.EntityUtils;
import org.apache.log4j.Logger;
import org.bson.Document;
import rules.RulesMatcher;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import static common.Constants.*;
import static org.apache.log4j.LogManager.getLogger;

public class ProfileToES {
    static Logger log = getLogger(ProfileToES.class.getName());

    public static void update(Document profileDoc) {
        String socialProfile = profileDoc.get(SOCIALPROFILE).toString();
        if(!Utility.isValid(socialProfile)) {
            log.info("No social profile exist"+profileDoc.get(ID));
            return;
        }
        List<String> socialProfiles= getSocialProfiles(socialProfile);
        Document requestDoc = new Document();
        requestDoc.put(SOCIAL_PROFILES, socialProfiles);
        requestDoc.put(REQUIRED, Arrays.asList(PUP_ID, EMAIL_LIST, CONTACTS));

        Document ProfileMatchingResponse = API(GET_URL, GET_API_KEY,requestDoc);
        updateInES(ProfileMatchingResponse, profileDoc);
    }

    public static void updateInES(Document responseDoc, Document profileDoc) {
        if(responseDoc.get(STATUS).equals(404)) {
            log.info("No profile matched In ES for "+profileDoc.get(ID));
            return;
        }
        Document profileInES = (Document) responseDoc.get(DATA);

        Document newProfileData = new Document();
        newProfileData.put(PUP_ID, profileInES.get(PUP_ID));
        newProfileData.put(EMAIL_LIST, getEmail(profileInES, profileDoc));
        newProfileData.put(CONTACTS, getContacts(profileInES, profileDoc));

        Document updatedResponse = API(UPDATE_URL, UPDATE_API_KEY,newProfileData);
        log.info(updatedResponse.toJson());
    }
    public static List<String> getSocialProfiles(String socialProfiles) {
        List<String> urls = new ArrayList<>();
        urls.add(socialProfiles);
        return urls;
    }

    public static Document API(String URL, String apiKey, Document requestDoc) {
        try(CloseableHttpClient client = HttpClientBuilder.create().build()) {
            String reqBody = requestDoc.toJson();
            HttpPost httpPost = new HttpPost(URL);
            httpPost.setHeader("content-type","application/json");
            httpPost.setHeader("Accept-Encoding", "UTF-8");
            httpPost.setHeader("api-key", apiKey);
            httpPost.setEntity(new StringEntity(reqBody,"UTF-8"));

            HttpResponse httpResponse = client.execute(httpPost);
            String responseInString = EntityUtils.toString(httpResponse.getEntity());
            Document responseDoc = Document.parse(responseInString);
            return responseDoc;
        } catch (IOException e) {
            throw new RuntimeException(e);
        }
    }

    public static List<Document> getEmail(Document profileInES, Document profileDoc) {
        List<Document> newEmailList = new ArrayList<>();
        if(!Utility.isValid(profileDoc.get(EMAIL))) {
            log.info("No emails to update"+profileDoc.get(ID));
            return newEmailList;
        }

        String emailInMongo = profileDoc.getString(EMAIL);
        List<Document> existingEmails = (List<Document>) profileInES.get(EMAIL_LIST);
        boolean flag = false;
        for(Document email : existingEmails) {
            if(emailInMongo.equals(email.get(EMAIL))) {
                newEmailList.add(RulesMatcher.rules(email, emailInMongo, 1, 1));
                flag = true;
                break;
            }
        }
        if(!flag)
            newEmailList.add(RulesMatcher.rules(new Document(), emailInMongo, 1, 2));
        return newEmailList;
    }

    public static List<Document> getContacts(Document profileInES, Document profileDoc) {
        List<Document> contactsList = new ArrayList<>();
        List<String> newContacts = (List<String>) profileDoc.get(CONTACTS_PROCESS);
        if(newContacts == null || newContacts.isEmpty()) {
            log.info("No contacts to update"+profileDoc.get(ID));
            return contactsList;
        }

        List<Document> existingContacts = (List<Document>) profileInES.get(CONTACTS);
        for(String newContact : newContacts) {
            boolean flag = false;
            for(Document contact : existingContacts) {
                if(newContact.equals(contact.getString(PHONENUMBER))) {
                    contactsList.add(RulesMatcher.rules(contact, newContact, 2, 1));
                    flag = true;
                    break;
                }
            }
            if(!flag)
                contactsList.add(RulesMatcher.rules(new Document(), newContact, 2, 2));
        }
        return contactsList;
    }
}
