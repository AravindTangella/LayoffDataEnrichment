package org.example;

import com.mongodb.MongoClient;
import com.mongodb.MongoClientURI;
import com.mongodb.client.MongoCollection;
import com.mongodb.client.model.Filters;
import common.Utility;
import org.apache.log4j.Logger;
import org.bson.Document;
import standardisation.PhoneNumberStandardisation;

import java.util.ArrayList;
import java.util.List;

import static common.Constants.*;

import static org.apache.log4j.LogManager.getLogger;

public class ProfileProcessor {
    public static final com.mongodb.MongoClient mongoClient = new MongoClient(new MongoClientURI("mongodb://localhost:27017/?serverSelectionTimeoutMS=5000&connectTimeoutMS=10000&3t.uriVersion=3&3t.connection.name=Products&3t.alwaysShowAuthDB=true&3t.alwaysShowDBFromUserRole=true"));
    static MongoCollection<Document> employees = mongoClient.getDatabase("CRM").getCollection("dummy");
    static Logger log = getLogger(ProfileProcessor.class.getName());
    public static void processProfile(Document profileDoc) {
        try {
            List<String> contacts_process = new ArrayList<>();
            if(Utility.isValid(profileDoc.get(CONTACTS))) {
                String contacts[] = profileDoc.get(CONTACTS).toString().split(SEPARATOR);
                for (String contact : contacts) {
                    String countryCode = PhoneNumberStandardisation.getCountryCode(contact);
                    String stdPhNo = PhoneNumberStandardisation.standardise(contact, countryCode);
                    contacts_process.add(stdPhNo == null ? contact : stdPhNo);
                }
            }
            updateInMongo(profileDoc, contacts_process);
            ProfileToES.update(employees.find(Filters.eq(ID, profileDoc.get(ID))).first());

        }catch(Exception e) {
            log.info(e.getMessage());
        }finally {
            mongoClient.close();
        }
    }

    public static void updateInMongo(Document profileDoc, List<String> contacts_process) {
        Document query = new Document();
        query.append(ID, profileDoc.get(ID));
        Document setData = new Document();
        setData.append(CONTACTS_PROCESS, contacts_process);
        setData.append(IS_PROCESSED, true);
        Document update = new Document();
        update.append(SET, setData);
        employees.updateOne(query, update);
    }
}
