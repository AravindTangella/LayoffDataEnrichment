package org.example;

import com.mongodb.MongoClient;
import com.mongodb.MongoClientURI;
import com.mongodb.client.MongoCollection;
import com.mongodb.client.MongoCursor;
import com.mongodb.client.model.Filters;
import org.apache.log4j.Logger;
import org.bson.Document;

import static org.apache.log4j.LogManager.getLogger;

public class Profiles {
    //Connecting to mongodb
    public static final  MongoClient mongoClient = new MongoClient(new MongoClientURI("mongodb://localhost:27017/?serverSelectionTimeoutMS=5000&connectTimeoutMS=10000&3t.uriVersion=3&3t.connection.name=Products&3t.alwaysShowAuthDB=true&3t.alwaysShowDBFromUserRole=true"));
    static Logger log = getLogger(Profiles.class.getName());
    public static void main(String[] args) {

        try {
            //Retrieving the collection from the database using mongoClient
            MongoCollection<Document> employees = mongoClient.getDatabase("CRM").getCollection("dummy");

            MongoCursor<Document> cursor = employees.find(Filters.eq("is_processed", false)).cursor();
            while(cursor.hasNext())
                ProfileProcessor.processProfile(cursor.next());
        }catch(Exception e) {
            log.error(e.getMessage());
        } finally {
            log.info("Inserted successfully");
        }

    }
}