package rules;


import org.bson.Document;

import java.time.Instant;
import java.util.ArrayList;
import java.util.List;

import static common.Constants.*;
public class RulesMatcher {
    public static Document rules(Document entityMatchedDoc, String entityValInMongo, int entity, int rule) {

        List<Document> existingSources = (List<Document>) entityMatchedDoc.get(SOURCES);
        List<Document> existingValidatedSources = (List<Document>) entityMatchedDoc.get(VALIDATED_SOURCE);

        List<Document> newSource = new ArrayList<>();
        Document updatedSource = new Document().append(SOURCE, LAYOFF)
                .append(UPDATED_DATE, Instant.now().toString());

        List<Document> newValidatedSource = new ArrayList<>();
        Document updatedValidatedSource = new Document().append(SOURCE, LAYOFF)
                .append(UPDATED_DATE, Instant.now().toString());


        switch(rule) {
                case 1: for(Document source : existingSources) {
                            if(LAYOFF.equals(source.getString(SOURCE))) {
                                newSource.add(getUpdatedDoc(updatedSource, source.getString(CREATED_DATE)));

                                for(Document validatedSource : existingValidatedSources) {
                                    if(LAYOFF.equals(validatedSource.getString(SOURCE))) {
                                        newValidatedSource.add(getUpdatedDoc(updatedValidatedSource, validatedSource.getString(CREATED_DATE)));

                                        return getEntityDoc(entity, entityValInMongo, true, newSource, newValidatedSource);

                                    }
                                }
                            }
                        }
                        newSource.add(getUpdatedDoc(updatedSource, Instant.now().toString()));
                        newValidatedSource.add(getUpdatedDoc(updatedValidatedSource, Instant.now().toString()));
                        return getEntityDoc(entity, entityValInMongo, true, newSource, newValidatedSource);

            case 2 :    newSource.add(getUpdatedDoc(updatedSource, Instant.now().toString()));
                        newValidatedSource.add(getUpdatedDoc(updatedValidatedSource, Instant.now().toString()));
                        return getEntityDoc(entity, entityValInMongo, true, newSource, newValidatedSource);
        }
        return new Document();
    }

    public static Document getUpdatedDoc(Document updatedDoc, String date) {
        updatedDoc.put(CREATED_DATE, date);
        return updatedDoc;
    }

    public static Document getEntityDoc(int entity, String entityValInMongo, boolean is_valid, List<Document> sources, List<Document> validatedSource) {
        Document newEntityDoc = new Document();
        newEntityDoc.put(entity == 1 ? EMAIL : PHONENUMBER, entityValInMongo);
        newEntityDoc.put(IS_VALID, is_valid);
        newEntityDoc.put(SOURCES, sources);
        newEntityDoc.put(VALIDATED_SOURCE, validatedSource);
        return newEntityDoc;
    }
}
