package common;

public class Constants {
    public static final String PLUS = "+";
    public static final String EMPTY = "";
    public static final String SOCIAL_PROFILES = "socialProfiles";
    public static final String GET_URL = "http://dna-profiles.prod.phenom.local/pup/api/v1/getMatchedProfileInfo";
    public static final String GET_API_KEY = "eJhyPpiOJy9SwiFcGUMWHc3Wry88UIPX";
    public static final String UPDATE_URL = "http://dev-dna-profiles-utility.aws.phenom.local/pup/api/v1/updatePUPProfileToES";
    public static final String UPDATE_API_KEY = "test";
    public static final String IS_PROCESSED = "is_processed";
    public static final String EMAIL = "email";
    public static final String CONTACTS = "contacts";
    public static final String ID = "_id";
    public static final String SEPARATOR = ",";
    public static final String CONTACTS_PROCESS = "contacts_process";
    public static final String SET = "$set";
    public static final String SOCIALPROFILE = "socialProfile";
    public static final String STATUS = "status";
    public static final String PUP_ID = "pupId";
    public static final String EMAIL_LIST = "emailList";
    public static final String SOURCES = "sources";
    public static final String SOURCE = "source";
    public static final String CREATED_DATE = "createdDate";
    public static final String UPDATED_DATE = "updatedDate";
    public static final String IS_VALID = "is_valid";
    public static final String VALIDATED_SOURCE = "validated_source";
    public static final String PHONENUMBER = "phoneNumber";
    public static final String DATA = "data";
    public static final String REQUIRED = "required";
    public static final String LAYOFF = "520";

}
