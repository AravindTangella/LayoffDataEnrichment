package common;

public class Constants {
    public static final String PLUS = "+";
    public static final String EMPTY = "";
    public static final String SOCIAL_PROFILES = "socialProfiles";
    public static final String GET_URL = "http://dna-profiles.prod.phenom.local/pup/api/v1/getMatchedProfileInfo";
    public static final String GET_API_KEY = "eJhyPpiOJy9SwiFcGUMWHc3Wry88UIPX";
    public static final String UPDATE_URL = "http://dev-dna-profiles-utility.aws.phenom.local/pup/api/v1/updatePUPProfileToES";
    public static final String UPDATE_API_KEY = "test";
}
