package common;

public class Utility {
    public static  boolean isValid(Object obj) {
        return obj == null || obj.toString().isEmpty() ? false : true;
    }
}
